BAJAJ BUSINESS MANAGER - ANDROID APK PROJECT

यो Android WebView wrapper project हो। यसले तिम्रो हालको Netlify app
https://silver-tiramisu-a937fa.netlify.app/ लाई Android app भित्र खोल्छ।

महत्त्वपूर्ण:
- यो ZIP आफैं APK होइन।
- GitHub Actions बाट free मा debug APK build गर्न मिल्ने workflow राखिएको छ।
- APK build गर्न GitHub account मा यो project repository upload गर्नुपर्छ।
- GitHub मा repository बनाएर सबै files upload/push गरेपछि:
  Actions > Build Android APK > Run workflow
- Build सकिएपछि workflow run को तल Artifacts मा
  Bajaj-Business-Manager-APK डाउनलोड गर्न मिल्छ।
- यो debug APK व्यक्तिगत रूपमा install/testing गर्न हो; Play Store upload का लागि
  release signing र Android target/API compliance छुट्टै चाहिन्छ।
- App ले Netlify website बाट data देखाउँछ। Website/browser मा राखेको localStorage
  र Android WebView को storage अलग हुन सक्छ। नियमित backup राख्नुहोस्।
- Website नै online हुनुपर्छ; internet चाहिन्छ।
